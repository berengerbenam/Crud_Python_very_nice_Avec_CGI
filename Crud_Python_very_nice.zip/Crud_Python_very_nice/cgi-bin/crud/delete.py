#!/usr/bin/python3
import pymysql,cgi,cgitb

def database():
    global conn,curseur
    conn=pymysql.connect(user="berenger",passwd="ping236",db="banque")
    curseur=conn.cursor()

def delete(id):
    req="delete from Clients where id=%s"
    database()
    val=(id,)
    curseur.execute(req,val)
    conn.commit()
    print("Content-Type:text/plain")
    print("")
    print("suppression reussi")

form=cgi.FieldStorage()
id=form.getvalue('id')

delete(id)
