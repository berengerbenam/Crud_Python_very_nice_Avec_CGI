#!/usr/bin/python3
import pymysql

def database():
    global conn,curseur
    conn=pymysql.connect(user="berenger",passwd="ping236",db="banque")
    curseur=conn.cursor()

def affiche():
    req="select * from Clients"
    database()
    curseur.execute(req)
    print("Content-Type:text/html")
    print("")
    print("<body><table border='5px'><tr><td>prenom</td><td>nom</td><td>email</td><td>code</td><td>solde</td></tr>")
    for row in curseur.fetchall():
        print(f"<tr><td>{row[1]}</td><td>{row[2]}</td><td>{row[3]}</td><td>{row[4]}</td><td>{row[5]}</td></tr>")
    print("</table></body>")

affiche()
