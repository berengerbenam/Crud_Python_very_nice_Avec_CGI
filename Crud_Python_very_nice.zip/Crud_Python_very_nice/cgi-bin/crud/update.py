#!/usr/bin/python3
import pymysql,cgi,cgitb

def database():
    global conn,curseur
    conn=pymysql.connect(user="berenger",passwd="ping236",db="banque")
    curseur=conn.cursor()

def update(id,solde):
    req="update Clients set solde=%s where id=%s"
    database()
    val=(solde,id)
    curseur.execute(req,val)
    conn.commit()
    print("Content-Type:text/plain")
    print("")
    print("mis a jour reussi")

form=cgi.FieldStorage()
id=form.getvalue('id')
solde=form.getvalue('solde')

update(id,solde)
