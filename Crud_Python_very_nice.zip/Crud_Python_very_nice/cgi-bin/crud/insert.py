#!/usr/bin/python3
import pymysql,cgi,cgitb

def database():
    global conn,curseur
    conn=pymysql.connect(user="berenger",passwd="ping236",db="banque")
    curseur=conn.cursor()

def insertion(nom,prenom,email,code,solde):
    req="insert into Clients(nom,prenom,email,code,solde) values(%s,%s,%s,%s,%s)"
    database()
    val=(nom,prenom,email,code,solde)
    curseur.execute(req,val)
    conn.commit()
    print("Content-Type:text/plain")
    print("")
    print("insertion reussi")

form=cgi.FieldStorage()
nom=form.getvalue('nom')
prenom=form.getvalue('prenom')
email=form.getvalue('email')
code=form.getvalue('code')
solde=form.getvalue('solde')

insertion(nom,prenom,email,code,solde)
