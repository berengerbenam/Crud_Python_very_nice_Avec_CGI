#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import cgi, cgitb
import pymysql

def database():
    global conn,cursor
    conn=mysql.connector.connect(host="localhost",user="berenger",passwd="ping236",database="banque")
    cursor=conn.cursor()


def inserer(prenom,nom,email,code,solde):
    sql="insert into Clients (prenom,nom,email,code,solde) values(%s,%s,%s,%s,%s)"
    database()
    val =(prenom,nom,email,code,solde)
    cursor.execute(sql,val)
    conn.commit()


print("Content-Type: text/html")
print()
print("<html><head><title>Comptes</title></head>")
print("<body>")

form = cgi.FieldStorage()
prenom = form.getvalue('prenom')
nom = form.getvalue('nom')
email = form.getvalue('email')

code = form.getvalue('code')
solde = form.getvalue('solde')
inserer(prenom,nom,email,code,solde)
print("Insertion reussie")
print("</body>")
print("</html>")
