#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import cgi, cgitb
import pymysql
def database():
    global conn,cursor
    conn=pymysql.connect(host="localhost",user="berenger",passwd="ping236",database="banque")
    cursor=conn.cursor()


def update(id,code,solde):
    sql="select code,solde from Clients where id=%s and code=%s"
    database()
    val = (id,code)
    cursor.execute(sql, val)
    tab=cursor.fetchone()
    if cursor.rowcount > 0:
        nouveausolde = float(tab[1]) + solde
        print(nouveausolde)
        sql1="update Clients set solde=%s where id=%s"
        val1=(nouveausolde,id)
        cursor.execute(sql1,val1)
        conn.commit()
        print ("Ajout effectue")
    else:
        print("Info erronee")

    print("Content-Type: text/html")
    print()
    print("<html><head><title>Comptes</title></head>")
    print("<body>")

    form = cgi.FieldStorage()
    id = form.getvalue('id')
    id = int(id)
    code = form.getvalue('code')
    solde = form.getvalue('solde')
    solde=float(solde)
    update(id,code,solde)
    print("</body>")
    print("</html>")

