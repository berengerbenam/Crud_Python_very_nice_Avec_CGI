#!/usr/bin/python3
import crud,cgi,cgitb
print("Content-Type:text/html")
print("")
print("<body>")
form=cgi.FieldStorage()
numcompte=form.getvalue('numcompte')

crud.delete(numcompte)
print("</body>")

