#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import cgi, cgitb
import mysql.connector
def database():
 global conn,cursor
 
conn=pymysql.connect(host="localhost",user="admin",passwd="ping236",database="databd")
cursor=conn.cursor()
def update(id,code,montant):
 sql="select code,solde from clients where id=%s and code=%s"
 database()
 val = (id,code)
 cursor.execute(sql, val)
 tab=cursor.fetchone()
 if cursor.rowcount > 0:
 nouveaumontant = float(tab[1]) + montant
 print(nouveaumontant)
 sql1="update clients set solde=%s where id=%s"
 val1=(nouveaumontant,id)
 cursor.execute(sql1,val1)
 conn.commit()
 print ("Ajout effectue")
 else:
 print("Info erronee")
print("Content-Type: text/html")
print()
print("<html><head><title>Comptes</title></head>")
print("<body>")
form = cgi.FieldStorage()
id = form.getvalue('id')
id = int(id)
code = form.getvalue('code')
montant = form.getvalue('montant')
montant=float(montant)
update(id,code,montant)
print("</body>")
print("</html>")
