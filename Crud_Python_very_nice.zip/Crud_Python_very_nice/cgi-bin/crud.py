#!/usr/bin/python3
import pymysql

def database():
    global conn,curseur
    conn = pymysql.connect(host='localhost',user='admin',passwd='ping236',database='databd')
    curseur=conn.cursor()


def lecture():
    sql="select * from client"
    database()
    curseur.execute(sql)
    tab=curseur.fetchall()
    print(tab)

def insertion(prenom,nom,numcompte,code,montant):
    sql="insert into client(prenom,nom,numcompte,code,montant) values(%s,%s,%s,%s,%s)"
    val=(prenom,nom,numcompte,code,montant)
    database()
    curseur.execute(sql,val)
    conn.commit()
    print("insertion reussie")


def update(numcompte,montant):
    sql="update client set montant=%s where numcompte=%s"
    val=(montant,numcompte)
    database()
    curseur.execute(sql,val)
    conn.commit()
    print("mise a jour effectue avec succes")


def delete(numcompte):
    sql="delete from client where numcompte=%s"
    val=(numcompte,)
    database()
    curseur.execute(sql,val)
    conn.commit()
    print("suppression reussie")






