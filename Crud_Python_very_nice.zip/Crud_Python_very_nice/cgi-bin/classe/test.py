#!/usr/bin/python3
print('Content-Type: text/plain')
print('')
print('Ceci est un test de CGI Number One !')




