#!/usr/bin/python3
import crud,cgi,cgitb
print("Content-Type:text/html")
print("")
print("<body>")
form=cgi.FieldStorage()
numcompte=form.getvalue('numcompte')
montant=form.getvalue('montant')

crud.update(numcompte,montant)
print("</body>")
