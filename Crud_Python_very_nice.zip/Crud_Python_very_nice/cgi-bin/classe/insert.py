#!/usr/bin/python3
import crud,cgi,cgitb
print("Content-Type:text/html")
print("")
print("<body>")
form=cgi.FieldStorage()
prenom=form.getvalue('prenom')
nom=form.getvalue('nom')
numcompte=form.getvalue('numcompte')
code=form.getvalue('code')
montant=form.getvalue('montant')

crud.insertion(prenom,nom,numcompte,code,montant)
print("</body>")
