#!/usr/bin/python3
import pymysql

def database():
    global conn,curseur
    conn = pymysql.connect(host='localhost',user='bouki3',passwd='passer',database='banque3')
    curseur=conn.cursor()

def lecture():
    sql="select * from client"
    database()
    curseur.execute(sql)
    tab=curseur.fetchall()
    return(tab)

print("Content-Type:text/html")
print()
print("<body><table border='1px'>")
print("<tr><td>Prenom</td><td>Nom</td><td>Numcompte</td><td>Code</td><td>Montant</td></tr>")
tab1=lecture()
for row in tab1:
    print(f"<tr><td>{row[1]}</td><td>{row[2]}</td><td>{row[3]}</td><td>{row[4]}</td><td>{row[5]}</td></tr>")


print("</table></body>")



